package rbaliwal00.reactspringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactspringdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
