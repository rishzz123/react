ALTER TABLE student
    ADD UNIQUE (email);