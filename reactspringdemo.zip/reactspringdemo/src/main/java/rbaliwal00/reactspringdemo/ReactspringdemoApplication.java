package rbaliwal00.reactspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactspringdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactspringdemoApplication.class, args);
	}

}
